#' @title carShare_NY
#' @description When starting time, starting place (latitude, longitude), destination (latitude, longitude), and weather (wind volume and precipitation) are added as factors, this function makes a proposal for a combination based on the probability of traffic congestion.
#' @usage carShare_NY(departTime, pick_lon, pick_lat, drop_lon, drop_lat, AWND, PRCP)
#' @param departTime integer: departure time
#' @param pick_lon integer : pickup longitude
#' @param pick_lat integer : pickup latitude
#' @param drop_lon integer : dropoff longitude
#' @param drop_lat integer : dropoff latitude
#' @param AWND integer : average wind speed
#' @param PRCP integer : precipitation
#' @export
#' @examples
#' carShare_NY(8, -74.005 , 40.736, -73.979 , 40.734, 6.93, 0.1)

carShare_NY <- function (departTime, pick_lon, pick_lat, drop_lon, drop_lat, AWND, PRCP) {
  glmm <- glm(data$rv ~ TIME + pickup_latitude + pickup_longitude + dropoff_longitude + dropoff_latitude + AWND + PRCP,
              family=binomial(link=logit), data, trace=F)
  log <- glmm$coefficients[1] +
    glmm$coefficients[2] * departTime +
    glmm$coefficients[3] * pick_lon +
    glmm$coefficients[4] * pick_lat +
    glmm$coefficients[5] * drop_lon +
    glmm$coefficients[6] * drop_lat +
    glmm$coefficients[7] * AWND +
    glmm$coefficients[8] * PRCP

  pi <- exp(log)
  traffic <- pi/(1+pi)
  traffic <- round(traffic*100, digits=0)

  #-33:원활, -66:보통, -100:혼잡
  result <- ""
  if (traffic < 33) result <- "교통이 원활합니다. 합승을 하지 않으셔도 괜찮습니다."
  else if(traffic < 66) result <- "교통이 보통 수준입니다. 합승을 하지 않으셔도 괜찮습니다."
  else result <- "교통이 혼잡합니다. 합승을 권장합니다."
  cat(result)
}
