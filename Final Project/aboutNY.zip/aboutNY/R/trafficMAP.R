
#' @title trafficMap_NY
#' @description Prints New York taxi's map. Map data should include latitude and longitude.
#' @usage trafficMap_NY(data)
#' @param data data : map data file with longitude, latitude
#' @export
#' @examples
#' trafficMap_NY(data)

#
#   Build and Reload Package:  'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

trafficMap_NY <- function(data) {
  #미국 주 데이터
  states <- map_data("state")

  #뉴욕주 데이터
  newyork <- subset(states, region %in% c("new york"))

  #뉴욕시 데이터
  ny <- subset(newyork, subregion %in% c("long island", "manhattan"))
  ny <- ny[ny$long >= -74.05 & ny$long <= -73.7, ]
  ny <- ny[ny$lat >= 40.5 & ny$lat <= 40.85, ]
  ny1 <- subset(ny, subregion %in% c("long island"))
  ny2 <- subset(ny, subregion %in% c("manhattan"))

  #택시 데이터


  lab <- data.frame(
    long = data$pickup_longitude, lat = data$pickup_latitude,
    longs =  data$dropoff_longitude, lats = data$dropoff_latitude,
    stringsAsFactors = FALSE
  )
  lab <- lab[lab$long >= -74.05 & lab$long <= -73.7, ]
  lab <- lab[lab$longs >= -74.05 & lab$longs <= -73.7, ]
  lab <- lab[lab$lat >= 40.5 & lab$lat <= 40.85, ]
  lab <- lab[lab$lats >= 40.5 & lab$lats <= 40.85, ]

  #0.5% 데이터 샘플링
  tmpnum <- sample(nrow(lab), 5000)
  tmpdata <- lab[tmpnum, ]

  #주행경로 그래프
  mapcolor <- rgb(0, 0, 0.7, alpha=0.01)
  ggplot() +
    geom_polygon(aes(x = ny1$long, y = ny1$lat), fill = "white", color = "grey") +
    geom_polygon(aes(x = ny2$long, y = ny2$lat), fill = "white", color = "grey") +
    geom_segment(data = tmpdata, aes(x = long, y = lat, xend=longs, yend=lats),
                 col= mapcolor, alpha=0.1)
}
