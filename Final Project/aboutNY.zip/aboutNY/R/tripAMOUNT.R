#' @title tripAmount_NY
#' @description Predicted trip amount of New York taxi with origin and destination. Know the latitude and longitude of the origin and destination.
#' @usage tripAmount_NY(departTime, payType, pick_lon, pick_lat, drop_lon, drop_lat)
#' @param departTime integer: departure time
#' @param payType character : paytype method used by passenger
#' @param pick_lon integer : pickup longitude
#' @param pick_lat integer : pickup latitude
#' @param drop_lon integer : dropoff longitude
#' @param drop_lat integer : dropoff latitude
#' @export
#' @examples
#' tripAmount_NY(8, "CRD", -74.005 , 40.736, -73.979 , 40.734)

trafficAmount_NY <- function (departTime, payType, pick_lon, pick_lat, drop_lon, drop_lat) {
  library(geosphere)
  fit1 <- lm(total_amount ~ payment_type + trip_time_in_secs + trip_distance, data)
  pick <- c(pick_lon, pick_lat)
  drop <- c(drop_lon, drop_lat)
  dist <- distGeo(pick, drop)/1000 #단위 : m
  velo <- tapply(rawdata$trip_distance/rawdata$trip_time_in_secs, rawdata$TIME, mean)
  velo <- velo/0.621371*1000 #단위 : m/s

  if (departTime == 24) departTime <- 0
  triptime <- dist/velo[departTime+1]
  result <- predict(fit1, newdata = data.frame(payment_type = payType,
                                               trip_time_in_secs = triptime,
                                               trip_distance = dist))
  cat(round(result, digits=2), "달러가 예상됩니다.")
}
