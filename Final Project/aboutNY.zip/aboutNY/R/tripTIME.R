#' @title tripTime_NY
#' @description It predicts the estimated time it takes from the World Trade Center to Central Park.
#' @usage tripTime_NY(departTime, rainForecast)
#' @param departTime integer: a dependent variable
#' @param rainForecast integer : precipitation
#' @export
#' @examples
#' tripTime_NY(8, 0.1)

tripTime_NY <- function (departTime, rainForecast) {
  fit2 <- lm(data$trip_time_in_secs ~ TIME + PRCP, data)
  result <- predict(fit2, newdata = data.frame(TIME=departTime,
                                               PRCP=as.numeric(rainForecast)))
  cat("세계무역센터-센트럴파크 : ", as.integer(result/60), "분이 예상됩니다.")
}
